#include<stdio.h>
#include<stdlib.h>
int main(void)
{

int r=3 ,c=3,i,j,count;

int *arr [i][j];


do
{
   arr[i][j]=(int*)malloc(*sizeof int);
       count=0;

   for(int i=0; i<r; i++)
     

    for(int j=0; j<c; j++)
	
	   arr[i][j] = ++count;

	for(int i=0; i<r; i++)

	for(int j=0; j<c; j++)
	
    	arr[i][j] = ++count;

	  int(i=0; i<r; i++);

	   free arr[1];

   printf("matrix is row order \n");

} while(i=0);

return 0;
}


